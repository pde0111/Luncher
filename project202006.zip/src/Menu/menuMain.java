package Menu;

import Menu.Service.CommonService;
import Menu.Service.CommonServiceImpl;
import javafx.application.Application;
import javafx.stage.Stage;

public class menuMain extends Application {

	MenuController m = new MenuController();

	@Override
	public void start(Stage primaryStage) throws Exception {

		CommonService comSrv = new CommonServiceImpl();
		comSrv.showWindow(primaryStage, "../menu.fxml", m);

	}

	public static void main(String[] args) {
		launch(args);
	}

}
