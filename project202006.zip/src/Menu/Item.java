package Menu;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;
// Table view를 위한 제품명,가격,수량을 저장하는 제품객체 
public class Item {
	private StringProperty name;
	private IntegerProperty price;
	private IntegerProperty quantity;

	public Item(StringProperty name, IntegerProperty price, IntegerProperty quantity) {
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}

	public StringProperty nameProperty() {
	    return name;
	}
	public IntegerProperty priceProperty() {
	    return price;
	}   
	public IntegerProperty quantityProperty() {
	    return quantity;
	}


	

	
}
