package Menu;

import javafx.scene.control.Label;

public class Infomation {
	private String imgInfo;
	private String imgName;
	private String imgPrice;
	private int num;
	
	public Infomation() {
		// TODO Auto-generated constructor stub
	}
	public Infomation(String imgName, String imgPrice, String imgInfo) {
		this.imgInfo = imgInfo;
		this.imgName = imgName;
		this.imgPrice = imgPrice;
		
	}
	
	public void setNum(int num) {
		this.num = num;
	}
	
	public String getImgInfo() {
		return imgInfo;
	}
	public String getImgName() {
		return imgName;
	}
	public String getImgPrice() {
		return imgPrice;
	}
	public int getNum() {
		return num;
	}
	
	
}
