package Menu.Service;

import javafx.scene.Parent;
import javafx.scene.control.TextField;

public class SelectedMenuServiceImpl implements SelectedMenuService{
	// 선택된 제품의 수량을 +,- 해주는 메서드
	@Override
	public void PlusMinus(Parent root, String oper) {
		TextField quantityTxt = (TextField)root.lookup("#quantity");
		int quantity = Integer.parseInt(quantityTxt.getText());
		
		if(oper.equals("+")) {
			quantity++;
			quantityTxt.setText(quantity+"");
		}
		if(oper.equals("-")){
			if(quantity == 1) {
				return;
			}
			quantity--;
			quantityTxt.setText(quantity+"");
		}
		
	}

	
}
