package Menu.Service;

import javafx.scene.Parent;

public interface SelectedMenuService {
	public void PlusMinus(Parent root, String oper);// 선택된 제품의 수량을 +,- 해주는 메서드
}
