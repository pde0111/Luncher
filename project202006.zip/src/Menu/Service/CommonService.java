package Menu.Service;


import java.util.Map;

import Menu.Controller;
import Menu.Infomation;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public interface CommonService {
	// 일반적으로 사용되는 기능들
	public void WindowClose(ActionEvent event); // 창 닫는 메소드
	public Parent showWindow(Stage s,String formPath); 
	
	//한번 해보기
	public Parent showWindow(Stage s, String formPath, Controller baseCont);
	public Parent showWindow(Stage s, String formPath, Controller baseCont, Infomation i);
	
	public void ErrorMsg(ActionEvent event, String title, String headerStr, String ContentTxt);
	public void ErrorMsg(String title, String headerStr, String ContentTxt);
	public void ErrorMsg(String headerStr, String ContentTxt);
	public void ErrorMsg(String ContentTxt);
	
}


