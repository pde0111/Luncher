package DAO;

import java.sql.SQLException;

import Menu.Infomation;

public interface DatabaseService {
	
	public Infomation Select(String name);
}
