package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Menu.Infomation;

public class DatabaseServiceImpl implements DatabaseService{
	final static String DRIVER = "oracle.jdbc.driver.OracleDriver";
	final static String url = "jdbc:oracle:thin:@127.0.0.1:1521:XE";
	final static String user = "system";
	final static String pass = "oracle";
	
	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;
	private Infomation Info;
	
	static {
		try {
			Class.forName(DRIVER);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public Infomation Select(String name) {
		// TODO Auto-generated method stub
		
		try {
			con = DriverManager.getConnection(url,user,pass);
			String sql = "select * from products where name=?";
			ps = con.prepareStatement(sql);
			ps.setString(1,name);
			rs = ps.executeQuery();	
			
			if(!rs.next()) {
				System.out.println("데이터 없음");
				return null;
			}
			
			int price = rs.getInt("price");
			String img = rs.getString("img");
			int quantity = rs.getInt("quantity");
			int selected = rs.getInt("selected");
			
			
			System.out.println("정보들 나열 : " + name + " / " + price + " / " + img + " / " + quantity + " / " + selected);
			
			Info = new Infomation(name, Integer.toString(price), img);
			
			rs.close();
			ps.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return Info;
	}

}
