package FXML;

import java.util.List;

import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.stage.Stage;

public interface comserv {
	public Parent WinShow (Stage stage,String Path);
	public void WinClose (ActionEvent e);
	public void allclose ();
	
	
}
