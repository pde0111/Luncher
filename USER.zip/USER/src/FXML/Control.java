package FXML;

import javafx.scene.Parent;

public abstract class Control {
	public abstract void setRoot(Parent root);
}
