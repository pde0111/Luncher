package UserState;

import javafx.event.ActionEvent;
import javafx.scene.Parent;

public interface Stateserv {
	

	
	public void Countime (Parent root); //시간출력
	
}
